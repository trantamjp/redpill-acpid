#!/bin/sh

case $1 in
  start)
    insmod /lib/modules/button.ko > /dev/null 2>&1
    ;;
  stop)
    exit 0
    ;;
  *)
    exit 1
    ;;
esac

